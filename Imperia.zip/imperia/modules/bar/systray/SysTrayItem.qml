import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Quickshell
import Quickshell.Services.SystemTray
import Quickshell.Widgets
import qs.modules.theme
import qs.modules.services
import qs.modules.components
import qs.config

MouseArea {
    id: root

    required property var bar
    required property SystemTrayItem item
    property int trayItemSize: 20

    acceptedButtons: Qt.LeftButton | Qt.RightButton
    Layout.fillHeight: bar.orientation === "horizontal"
    Layout.fillWidth: bar.orientation === "vertical"
    implicitWidth: trayItemSize
    implicitHeight: trayItemSize
    
    onClicked: event => {
        switch (event.button) {
        case Qt.LeftButton:
            item.activate();
            break;
        case Qt.RightButton:
            if (item.hasMenu) {
                systrayPopup.toggle();
            }
            break;
        }
        event.accepted = true;
    }

    BarPopup {
        id: systrayPopup
        anchorItem: root
        bar: root.bar
        
        // Use a reasonable width for the menu
        contentWidth: 220
        // Height adapts to content, with a max limit if needed.
        // Must include vertical padding (8 top + 8 bottom = 16)
        contentHeight: Math.min(itemsColumn.implicitHeight + 16, 400)
        
        popupPadding: 8
        // 8px standard margin + 8px SysTray container padding to ensure correct offset from the main bar
        visualMargin: 16

        // Using QsMenuOpener to access menu items
        QsMenuOpener {
            id: menuOpener
            menu: root.item.menu
        }

        ScrollView {
            anchors.fill: parent
            contentWidth: availableWidth
            clip: true
            
            ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
            
            ColumnLayout {
                id: itemsColumn
                width: parent.width
                spacing: 2

                Repeater {
                    model: menuOpener.children ? menuOpener.children.values : []
                    
                    delegate: SystrayMenuItem {
                        required property var modelData
                        
                        Layout.fillWidth: true
                        
                        textStr: modelData.text || ""
                        iconSource: modelData.icon || ""
                        // Simple heuristic for image icon
                        isImageIcon: iconSource.indexOf("/") !== -1 || iconSource.indexOf(".") !== -1
                        isSeparator: modelData.isSeparator || false
                        
                        onClicked: {
                            if (modelData.triggered) {
                                modelData.triggered();
                            } else if (modelData.activate) {
                                modelData.activate();
                            }
                            systrayPopup.close();
                        }
                    }
                }
            }
        }
    }

    IconImage {
        id: trayIcon
        source: {
            const iconPath = root.item.icon.toString();
            if (iconPath.includes("spotify")) {
                return Quickshell.iconPath("spotify-client");
            }
            return root.item.icon;
        }
        anchors.centerIn: parent
        width: parent.width
        height: parent.height
        smooth: true
    }

    Tinted {
        sourceItem: trayIcon
        anchors.fill: trayIcon
    }

    // Caelestia-style hover scale
    HoverHandler { id: trayHover }
    scale: root.pressed ? 0.88 : (trayHover.hovered ? 1.15 : 1.0)
    Behavior on scale {
        NumberAnimation {
            duration: trayHover.hovered ? 200 : 100
            easing.type: trayHover.hovered ? Easing.OutBack : Easing.OutCubic
            easing.overshoot: 1.5
        }
    }
}
