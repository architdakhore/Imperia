//@ pragma UseQApplication
//@ pragma ShellId imperia
//@ pragma DataDir $BASE/imperia
//@ pragma StateDir $BASE/imperia
//@ pragma CacheDir $BASE/imperia

import QtQuick
import Quickshell
import Quickshell.Wayland
import qs.modules.bar
import qs.modules.bar.workspaces
import qs.modules.notifications
import qs.modules.widgets.dashboard.wallpapers

import qs.modules.notch
import qs.modules.widgets.overview
import qs.modules.widgets.presets
import qs.modules.services
import qs.modules.corners
import qs.modules.frame
import qs.modules.components
import qs.modules.desktop
import qs.modules.lockscreen
import qs.modules.dock
import Quickshell.Io
import qs.modules.globals
import qs.modules.shell
import qs.config
import qs.modules.shell.osd
import "modules/tools"

ShellRoot {
    id: root

    // ── Fonts: Font Awesome 6 Free (all UI icons) ────────────────────────────
    // Requires: paru -S ttf-font-awesome   (Arch Linux AUR)
    // FA6 Free has 2000+ icons. Codepoints \uf000-\uf2ff and beyond.
    FontLoader {
        id: fa6SolidLoader
        source: {
            var paths = [
                "/usr/share/fonts/OTF/Font Awesome 6 Free-Solid-900.otf",
                "/usr/share/fonts/fontawesome/Font Awesome 6 Free-Solid-900.otf",
                "/usr/share/fonts/TTF/fa-solid-900.ttf",
                "/usr/local/share/fonts/Font Awesome 6 Free-Solid-900.otf"
            ];
            for (var i = 0; i < paths.length; i++)
                return paths[i];
            return paths[0];
        }
    }
    FontLoader {
        id: fa6BrandsLoader
        source: {
            var paths = [
                "/usr/share/fonts/OTF/Font Awesome 6 Brands-Regular-400.otf",
                "/usr/share/fonts/fontawesome/Font Awesome 6 Brands-Regular-400.otf",
                "/usr/share/fonts/TTF/fa-brands-400.ttf"
            ];
            return paths[0];
        }
    }

    ContextMenu {
        id: contextMenu
        screen: Quickshell.screens[0]
        Component.onCompleted: Visibilities.setContextMenu(contextMenu)
    }

    Variants {
        model: Quickshell.screens

        Loader {
            id: wallpaperLoader
            active: true
            required property ShellScreen modelData
            sourceComponent: Wallpaper {
                screen: wallpaperLoader.modelData
            }
        }
    }

    Variants {
        model: Quickshell.screens

        Loader {
            id: desktopLoader
            active: Config.desktop.enabled && SuspendManager.wakeReady
            required property ShellScreen modelData
            sourceComponent: Desktop {
                screen: desktopLoader.modelData
            }
        }
    }

    // Visual panel & reservations
    Variants {
        model: Quickshell.screens

        Item {
            id: screenShellContainer
            required property ShellScreen modelData

            // Panel components (Bar, Notch, Dock, Frame, Corners)
            UnifiedShellPanel {
                id: unifiedPanel
                targetScreen: screenShellContainer.modelData
            }

            ScreenCorners {
                screen: screenShellContainer.modelData
            }

            // Exclusive zone reservations
            ReservationWindows {
                screen: screenShellContainer.modelData

                // Bar status for reservations
                barEnabled: {
                    const list = Config.bar?.screenList ?? [];
                    return (!list || list.length === 0 || list.indexOf(screen.name) !== -1);
                }
                barPosition: unifiedPanel.barPosition
                barPinned: unifiedPanel.pinned
                barSize: (unifiedPanel.barPosition === "left" || unifiedPanel.barPosition === "right") ? unifiedPanel.barTargetWidth : unifiedPanel.barTargetHeight
                barOuterMargin: unifiedPanel.barOuterMargin

                // Dock status for reservations
                dockEnabled: {
                    if (!(Config.dock?.enabled ?? false) || (Config.dock?.theme ?? "default") === "integrated")
                        return false;

                    const list = Config.dock?.screenList ?? [];
                    if (!list || list.length === 0)
                        return true;
                    return list.indexOf(screenShellContainer.modelData.name) !== -1;
                }
                dockPosition: unifiedPanel.dockPosition
                dockPinned: unifiedPanel.dockPinned
                dockHeight: unifiedPanel.dockHeight
                containBar: unifiedPanel.containBar

                frameEnabled: Config.bar?.frameEnabled ?? false
                frameThickness: Config.bar?.frameThickness ?? 6
            }
        }
    }

    // Overview popup
    Variants {
        model: {
            const screens = Quickshell.screens;
            const list = Config.bar?.screenList ?? [];
            if (!list || list.length === 0)
                return screens;
            return screens.filter(screen => list.indexOf(screen.name) !== -1);
        }

        Loader {
            id: overviewLoader
            active: (Config.overview?.enabled ?? true) && SuspendManager.wakeReady
            required property ShellScreen modelData
            sourceComponent: OverviewPopup {
                screen: overviewLoader.modelData
            }
        }
    }

    // Presets popup
    Variants {
        model: {
            const screens = Quickshell.screens;
            const list = Config.bar?.screenList ?? [];
            if (!list || list.length === 0)
                return screens;
            return screens.filter(screen => list.indexOf(screen.name) !== -1);
        }

        Loader {
            id: presetsLoader
            active: SuspendManager.wakeReady
            required property ShellScreen modelData
            sourceComponent: PresetsPopup {
                screen: presetsLoader.modelData
            }
        }
    }

    // Secure WlSessionLock lockscreen
    WlSessionLock {
        id: sessionLock
        locked: GlobalStates.lockscreenVisible

        // Surface auto-created per screen
        LockScreen {}
    }

    HyprlandConfig {
        id: hyprlandConfig
    }

    HyprlandKeybinds {
        id: hyprlandKeybinds
    }

    // Screenshot tool
    Variants {
        model: Quickshell.screens

        Loader {
            id: screenshotLoader
            active: GlobalStates.screenshotToolVisible
            required property ShellScreen modelData
            sourceComponent: ScreenshotTool {
                targetScreen: screenshotLoader.modelData
            }
        }
    }

    // Screenshot preview overlay
    Variants {
        model: Quickshell.screens

        Loader {
            id: screenshotOverlayLoader
            active: SuspendManager.wakeReady
            required property ShellScreen modelData
            sourceComponent: ScreenshotOverlay {
                targetScreen: screenshotOverlayLoader.modelData
            }
        }
    }

    // Screen recording tool
    Loader {
        id: screenRecordLoader
        active: SuspendManager.wakeReady
        source: "modules/tools/ScreenrecordTool.qml"

        Connections {
            target: GlobalStates
            function onScreenRecordToolVisibleChanged() {
                if (screenRecordLoader.status === Loader.Ready) {
                    if (GlobalStates.screenRecordToolVisible) {
                        screenRecordLoader.item.open();
                    } else {
                        screenRecordLoader.item.close();
                    }
                }
            }
        }

        Connections {
            target: screenRecordLoader.item
            ignoreUnknownSignals: true
            function onVisibleChanged() {
                if (!screenRecordLoader.item.visible && GlobalStates.screenRecordToolVisible) {
                    GlobalStates.screenRecordToolVisible = false;
                }
            }
        }
    }

    // Mirror tool
    Loader {
        id: mirrorLoader
        active: SuspendManager.wakeReady
        source: "modules/tools/MirrorWindow.qml"
    }

    // Settings
    Loader {
        id: settingsWindowLoader
        active: SuspendManager.wakeReady
        source: "modules/widgets/config/SettingsWindow.qml"
    }

    // Control Center (combined DankMaterial + Caelestia + Illogical Impulse)
    Loader {
        id: controlCenterLoader
        active: SuspendManager.wakeReady
        source: "modules/widgets/controlcenter/ControlCenterWindow.qml"
    }

    // On-screen display
    // Old pill OSD replaced by right-edge interactive OSD below
    // Variants {
    //     model: Quickshell.screens
    //     OSD { targetScreen: modelData }
    // }

    // Right-edge OSD (user's style): interactive brightness + volume sliders
    Variants {
        model: Quickshell.screens

        RightEdgeOSD {
            targetScreen: modelData
        }
    }

    // Init clipboard service
    Connections {
        target: ClipboardService
        function onListCompleted() {
        // Service initialized and ready
        }
    }

    // Force service init at startup
    QtObject {
        id: serviceInitializer

        // Force colorful tela-circle icon theme (not the -nord-dark monochrome variant)
        property Process iconThemeProcess: Process {
            id: iconThemeProcess
            command: ["sh", "-c",
                "gsettings set org.gnome.desktop.interface icon-theme 'tela-circle' && " +
                "gsettings set org.gnome.desktop.interface color-scheme 'default'"
            ]
            running: false
        }

        Component.onCompleted: {
            // Force tela-circle (colorful) icon theme immediately
            iconThemeProcess.running = true;

            // Trigger service creation
            let _ = NightLightService.active;
            _ = GameModeService.toggled;
            _ = CaffeineService.inhibit;
            _ = IdleService.lockCmd; // Force init
            _ = GlobalShortcuts.appId; // Force init
        }
    }
}
