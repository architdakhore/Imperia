.pragma library

var data = {
    "enabled": true,
    "theme": "default",
    "position": "bottom",
    "height": 48,
    "iconSize": 24,
    "spacing": 4,
    "margin": 4,
    "hoverRegionHeight": 16,
    "pinnedOnStartup": false,
    "hoverToReveal": true,
    "availableOnFullscreen": false,
    "showRunningIndicators": true,
    "showPinButton": true,
    "showOverviewButton": true,
    "ignoredAppRegexes": [
        "quickshell.*",
        "xdg-desktop-portal.*"
    ],
    "screenList": [],
    "keepHidden": false
}
