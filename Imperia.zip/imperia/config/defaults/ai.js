var data = {
    "systemPrompt": "You are a helpful assistant running on a Linux system. You have access to some tools to control the system.",
    "tool": "none",
    "extraModels": [],
    "defaultModel": "gemini-pro"
}
