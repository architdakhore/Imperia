.pragma library

var data = {
    "enabled": false,
    "iconSize": 40,
    "spacingVertical": 16,
    "textColor": "overBackground"
}
