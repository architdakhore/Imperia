.pragma library

var data = {
    "blurTransition": true,
    "windowPreview": true,
    "wavyLine": true,
    "rotateCoverArt": true,
    "dashboardPersistTabs": false,
    "dashboardMaxPersistentTabs": 2
}
